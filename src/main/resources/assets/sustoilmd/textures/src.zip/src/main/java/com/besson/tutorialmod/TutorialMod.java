package com.besson.tutorialmod;

import com.besson.tutorialmod.block.ModBlocks;
import com.besson.tutorialmod.block.ModFluids;
import com.besson.tutorialmod.block.entity.ModBlockEntities;
import com.besson.tutorialmod.entity.ModBoats;
import com.besson.tutorialmod.item.ModItemGroups;
import com.besson.tutorialmod.item.ModItems;
import com.besson.tutorialmod.mixin.GrassColorsMixin;
import com.besson.tutorialmod.recipe.ModRecipeTypes;
import com.besson.tutorialmod.screen.ModScreenHandlers;
import com.besson.tutorialmod.sound.ModSoundEvents;
import com.besson.tutorialmod.tags.ModBlockTags;
import com.besson.tutorialmod.util.ModCustomTrades;
import com.besson.tutorialmod.util.ModLootTableModifiers;
import com.besson.tutorialmod.villager.ModVillagers;
import com.besson.tutorialmod.world.gen.ModWorldGeneration;
import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TutorialMod implements ModInitializer {
	// This logger is used to write text to the console and the log file.
	// It is considered best practice to use your mod id as the logger's name.
	// That way, it's clear which mod wrote info, warnings, and errors.
	public static final String MOD_ID = "tutorialmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// This code runs as soon as Minecraft is in a mod-load-ready state.
		// However, some things (like resources) may still be uninitialized.
		// Proceed with mild caution.
		// 调用各类的初始化方法
		ModItems.registerModItems();
		ModItemGroups.registerModItemGroups();
		ModBlocks.registerModBlocks();
		ModBlockTags.registerModBlockTags();
		ModLootTableModifiers.modifyLootTable();
		ModCustomTrades.registerModCustomTrades();
		ModVillagers.registerModVillagers();
		ModSoundEvents.registerModSoundEvents();
		ModFluids.registerModFluids();
		ModBlockEntities.registerBlockEntities();
		ModScreenHandlers.registerScreenHandlers();
		ModRecipeTypes.registerRecipeTypes();
		ModBoats.registerModBoats();
		ModWorldGeneration.registerWorldGenerations();

		StrippableBlockRegistry.register(ModBlocks.ICE_ETHER_LOG, ModBlocks.STRIPPED_ICE_ETHER_LOG);
		StrippableBlockRegistry.register(ModBlocks.ICE_ETHER_WOOD, ModBlocks.STRIPPED_ICE_ETHER_WOOD);

		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.ICE_ETHER_LOG, 5, 5);
		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.ICE_ETHER_WOOD, 5, 5);
		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.STRIPPED_ICE_ETHER_LOG, 5, 5);
		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.STRIPPED_ICE_ETHER_WOOD, 5, 5);
		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.ICE_ETHER_LEAVES, 30, 60);
		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.ICE_ETHER_PLANKS, 5, 20);


//		int[] colorMap = GrassColorsMixin.getColorMap();
//        LOGGER.info("Grass color map length: {}", colorMap.length);
//
//		int[] newColorMap = new int[128];
//		GrassColorsMixin.setColorMap(newColorMap);
//		LOGGER.info("Grass color map length: {}", GrassColorsMixin.getColorMap().length);

//		FuelRegistry.INSTANCE.add(ModItems.ANTHRACITE, 1600);

		LOGGER.info("Hello Fabric world!");
	}
}