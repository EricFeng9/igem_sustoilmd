package com.besson.tutorialmod.world.gen;

public class ModWorldGeneration {
    public static void registerWorldGenerations() {
        ModTreeGeneration.registerTrees();
        ModFlowerGeneration.generateFlowers();
        ModOreGeneration.generateOres();
    }
}
